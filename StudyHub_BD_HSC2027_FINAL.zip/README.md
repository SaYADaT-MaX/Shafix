# StudyHub BD — Final HSC 2027

A ready-to-deploy Node/Express web app for a student assignment community.

## Included
- Real registration/login with bcrypt password hashing
- JWT sessions
- Admin panel
- Weekly assignment publishing
- Student submissions
- Public-to-logged-in-users solution viewing
- Comments
- Admin user/submission view
- SQLite persistence while the host keeps the filesystem persistent

## Deploy
Use a Node hosting service with persistent storage/database. Set:
- `JWT_SECRET` = a long random secret
- `ADMIN_PHONE` = your admin phone
- `ADMIN_PASSWORD` = a strong admin password

Start command: `npm start`

## Important
This is a complete starter application, but hosting-specific database persistence, backups, rate limiting, HTTPS and moderation policies should be configured before public launch. Do not display students' phone numbers publicly. Passwords are never exposed to the admin.

The default admin credentials are only a fallback for first boot; set environment variables before deployment.
