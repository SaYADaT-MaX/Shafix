const express=require("express"),path=require("path"),bcrypt=require("bcryptjs"),jwt=require("jsonwebtoken"),Database=require("better-sqlite3");
const app=express(),db=new Database(process.env.DB_PATH||"studyhub.db"),SECRET=process.env.JWT_SECRET||"replace-this-secret";
app.use(express.json({limit:"300kb"}));app.use(express.static(path.join(__dirname,"public")));
db.exec(`CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'student',created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS assignments(id INTEGER PRIMARY KEY AUTOINCREMENT,week TEXT NOT NULL,subject TEXT NOT NULL,title TEXT NOT NULL,description TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS submissions(id INTEGER PRIMARY KEY AUTOINCREMENT,assignment_id INTEGER NOT NULL,user_id INTEGER NOT NULL,answer TEXT NOT NULL,created_at TEXT NOT NULL,UNIQUE(assignment_id,user_id));
CREATE TABLE IF NOT EXISTS comments(id INTEGER PRIMARY KEY AUTOINCREMENT,submission_id INTEGER NOT NULL,user_id INTEGER NOT NULL,text TEXT NOT NULL,created_at TEXT NOT NULL);`);
if(!db.prepare("SELECT id FROM users WHERE role='admin'").get()){
 const p=process.env.ADMIN_PASSWORD||"ChangeThisAdminPassword123!";
 db.prepare("INSERT INTO users(name,phone,password_hash,role,created_at) VALUES(?,?,?,?,?)").run("Admin",process.env.ADMIN_PHONE||"01700000000",bcrypt.hashSync(p,12),"admin",new Date().toISOString());
}
if(!db.prepare("SELECT id FROM assignments").get()){
 const q=db.prepare("INSERT INTO assignments(week,subject,title,description,created_at) VALUES(?,?,?,?,?)"),now=new Date().toISOString();
 [["Week 01","Physics","ভৌত জগৎ ও পরিমাপ","১০টি MCQ এবং ৩টি সৃজনশীল প্রশ্ন সমাধান করো।"],["Week 01","Chemistry","ল্যাবরেটরি নিরাপত্তা","নিরাপত্তার ১০টি নিয়ম এবং ১৫টি MCQ।"],["Week 01","Higher Math","ম্যাট্রিক্স ও নির্ণায়ক","৫টি নির্বাচিত সমস্যা ধাপে ধাপে সমাধান করো।"],["Week 01","Biology","কোষ","কোষের গঠন নিয়ে নোট এবং ১৫টি MCQ।"]].forEach(x=>q.run(...x,now));
}
function auth(req,res,next){try{const h=req.headers.authorization||"";if(!h.startsWith("Bearer "))throw 0;req.user=jwt.verify(h.slice(7),SECRET);next()}catch(e){res.status(401).json({error:"Login required"})}}
function admin(req,res,next){if(req.user.role!=="admin")return res.status(403).json({error:"Admin only"});next()}
app.post("/api/register",(req,res)=>{const {name,phone,password}=req.body||{};if(!name||!phone||!password||password.length<8)return res.status(400).json({error:"সব তথ্য দিন; password কমপক্ষে ৮ অক্ষরের"});try{db.prepare("INSERT INTO users(name,phone,password_hash,created_at) VALUES(?,?,?,?)").run(name,phone,bcrypt.hashSync(password,12),new Date().toISOString());res.json({ok:true})}catch(e){res.status(400).json({error:"এই নম্বর দিয়ে account আছে"})}});
app.post("/api/login",(req,res)=>{const u=db.prepare("SELECT * FROM users WHERE phone=?").get(req.body.phone||"");if(!u||!bcrypt.compareSync(req.body.password||"",u.password_hash))return res.status(401).json({error:"নম্বর বা password ভুল"});res.json({token:jwt.sign({id:u.id,name:u.name,role:u.role},SECRET,{expiresIn:"7d"}),user:{id:u.id,name:u.name,role:u.role}})});
app.get("/api/me",auth,(req,res)=>res.json(req.user));
app.get("/api/assignments",(req,res)=>res.json(db.prepare("SELECT * FROM assignments ORDER BY id DESC").all()));
app.post("/api/assignments",auth,admin,(req,res)=>{const {week,subject,title,description}=req.body;if(!week||!subject||!title||!description)return res.status(400).json({error:"সব ঘর পূরণ করুন"});const r=db.prepare("INSERT INTO assignments(week,subject,title,description,created_at) VALUES(?,?,?,?,?)").run(week,subject,title,description,new Date().toISOString());res.json({id:r.lastInsertRowid})});
app.delete("/api/assignments/:id",auth,admin,(req,res)=>{db.prepare("DELETE FROM assignments WHERE id=?").run(req.params.id);res.json({ok:true})});
app.post("/api/assignments/:id/submissions",auth,(req,res)=>{const a=(req.body.answer||"").trim();if(!a)return res.status(400).json({error:"সমাধান লিখুন"});try{const r=db.prepare("INSERT INTO submissions(assignment_id,user_id,answer,created_at) VALUES(?,?,?,?)").run(req.params.id,req.user.id,a,new Date().toISOString());res.json({id:r.lastInsertRowid})}catch(e){res.status(400).json({error:"এই assignment-এ ইতিমধ্যে submit করেছেন"})}});
app.get("/api/assignments/:id/submissions",auth,(req,res)=>{const rows=db.prepare("SELECT s.id,s.answer,s.created_at,u.name FROM submissions s JOIN users u ON u.id=s.user_id WHERE s.assignment_id=? ORDER BY s.id DESC").all(req.params.id);res.json(rows.map(s=>({...s,comments:db.prepare("SELECT c.id,c.text,c.created_at,u.name FROM comments c JOIN users u ON u.id=c.user_id WHERE c.submission_id=? ORDER BY c.id").all(s.id)})))});
app.post("/api/submissions/:id/comments",auth,(req,res)=>{const t=(req.body.text||"").trim();if(!t)return res.status(400).json({error:"Comment লিখুন"});const r=db.prepare("INSERT INTO comments(submission_id,user_id,text,created_at) VALUES(?,?,?,?)").run(req.params.id,req.user.id,t,new Date().toISOString());res.json({id:r.lastInsertRowid})});
app.get("/api/admin/users",auth,admin,(req,res)=>res.json(db.prepare("SELECT id,name,phone,role,created_at FROM users ORDER BY id DESC").all()));
app.get("/api/admin/submissions",auth,admin,(req,res)=>res.json(db.prepare("SELECT s.id,s.answer,s.created_at,u.name,u.phone,a.subject,a.title FROM submissions s JOIN users u ON u.id=s.user_id JOIN assignments a ON a.id=s.assignment_id ORDER BY s.id DESC").all()));
app.listen(process.env.PORT||3000,()=>console.log("StudyHub BD running"));
